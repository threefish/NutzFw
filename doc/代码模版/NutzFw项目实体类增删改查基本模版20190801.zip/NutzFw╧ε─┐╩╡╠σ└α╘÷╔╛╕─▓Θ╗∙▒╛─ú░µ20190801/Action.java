package #[base.actionPackage];

import com.nutzfw.core.common.annotation.AutoCreateMenuAuth;
import com.nutzfw.core.common.cons.Cons;
import com.nutzfw.core.common.filter.CheckRoleAndSession;
import com.nutzfw.core.common.vo.AjaxResult;
import com.nutzfw.core.common.vo.LayuiTableDataListVO;
import com.github.threefish.nutz.dto.PageDataDTO;
import com.nutzfw.modules.sys.biz.DictBiz;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.nutz.aop.interceptor.ioc.TransAop;
import org.nutz.dao.Cnd;
import org.nutz.dao.pager.Pager;
import org.nutz.ioc.aop.Aop;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;
import org.nutz.lang.Strings;
import org.nutz.lang.util.NutMap;
import org.nutz.log.Log;
import org.nutz.log.Logs;
import org.nutz.mvc.annotation.*;
import org.nutz.plugins.validation.Errors;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import #[base.entityPackage].#[base.entityName];
import #[base.servicePackage].#[base.serviceFileName];
<##if(base.oneOneRelation){##>
import java.util.ArrayList;
import java.util.List;
<##for(field in fields){##>
<##if(field.oneOne){##>
import #[field.oneOneClassQualifiedName];
<##}}}##>

/**
 * @author #[base.userName] #[base.userMail]
 * @date #[date(), dateFormat="yyyy年MM月dd日"]
 * #[base.funName]
 */
@Slf4j
@IocBean
@At("/#[base.entityName]")
@Filters(@By(type = CheckRoleAndSession.class, args = {Cons.SESSION_USER_KEY, Cons.SESSION_USER_ROLE}))
public class #[base.actionFileName] {

    final static Log log= Logs.get();

    @Inject
    #[base.serviceFileName] #[sp.uncapitalize(base.serviceFileName)];

    @Inject
    DictBiz dictBiz;

    <##if(base.oneOneRelation){##>
    <##for(field in fields){##>
    <##if(field.oneOne){##>
    @Inject
    #[base.servicePackage].#[field.oneOneClassName]Service #[sp.uncapitalize(field.oneOneClassName)]Service;

     /**
     * 关联表信息
     *
     * @param key
     * @return
     */
     @POST
     @At("/relation#[field.oneOneClassName]")
     @Ok("json:{ignoreNull:false,dateFormat:'yyyy-MM-dd'}")
     @RequiresPermissions("#[base.entityName].index")
     public LayuiTableDataListVO relation#[field.oneOneClassName](@Param("key") String key, @Param("id") String id,@Param("pageNum") int pageNum, @Param("pageSize") int pageSize) {
        PageDataDTO<#[field.oneOneClassName]> pageDataDTO;
        LayuiTableDataListVO returnListVO = new LayuiTableDataListVO();
        //TODO 这里的查询逻辑需要根据实际的字段修改
        if (Strings.isNotBlank(key)) {
            key = "%" + key + "%";
            //TODO 这里的key需要修改实际的字段
            pageDataDTO = #[sp.uncapitalize(field.oneOneClassName)]Service.listPageDto(pageNum, pageSize, Cnd.where("key", "like", key));
        } else if (Strings.isNotBlank(id)) {
            pageDataDTO = #[sp.uncapitalize(field.oneOneClassName)]Service.listPageDto(pageNum, pageSize, Cnd.where("uuid", "=", id));
        } else {
            pageDataDTO = #[sp.uncapitalize(field.oneOneClassName)]Service.listPageDto(pageNum, pageSize, Cnd.NEW());
        }
        List<NutMap> list = new ArrayList<>();
        pageDataDTO.getData().forEach(data -> list.add(new NutMap().setv("id", data.getId()).setv("text", MessageFormat.format("{0}", data.getUserName()))));
        returnListVO.setData(list);
        returnListVO.setCount(pageDataDTO.getCount());
        return returnListVO;
     }
    <##}}}##>

    /**
     * 管理页面
     *
     * @return
     */
    @At("/index")
    @Ok("btl:#[base.templatePath]index.html")
    @RequiresPermissions("#[base.entityName].index")
    @AutoCreateMenuAuth(name = "#[base.funName]管理", icon = "fa-cogs")
    public NutMap index() {
        NutMap data=NutMap.NEW();
        <##for(field in fields){##>
        <##if(field.dict){##>
        data.put("#[field.dictCode]",dictBiz.getDictEnumsJson("#[field.dictCode]"));
        <##}}##>
        return data;
    }

    /**
     * 列表管理
     *
     * @param pageNum
     * @param pageSize
     * @param key
     * @return
     */
    @At("/list")
    @Ok("json:{nullAsEmtry:true,dateFormat:'yyyy年MM月dd日'}")
    @RequiresPermissions("#[base.entityName].index")
    public LayuiTableDataListVO list(@Param("pageNum") int pageNum,
                                     @Param("pageSize") int pageSize,
                                     @Param("key") String key
    ) {
        Cnd cnd = Cnd.NEW();
        if (Strings.isNotBlank(key)) {
            cnd.and("name", "like", "%" + key + "%");
        }
        cnd.desc("opAt");
        return #[sp.uncapitalize(base.serviceFileName)].listPage(pageNum, pageSize, cnd);
    }

    /**
     * 新增、编辑保存页面
     *
     * @param #[base.primaryKey]
     * @return
     */
    @At("/edit")
    @Ok("btl:#[base.templatePath]edit.html")
    @RequiresPermissions("#[base.entityName].index.edit")
    @AutoCreateMenuAuth(name = "新增/编辑#[base.funName]", type = AutoCreateMenuAuth.RESOURCE, icon = "fa-cogs", parentPermission = "#[base.entityName].index")
    public NutMap edit(@Param("#[base.primaryKey]") String #[base.primaryKey]) {
        return NutMap.NEW().setv("#[base.primaryKey]", #[base.primaryKey]).setv("fromDataEdit", true);
    }

    /**
     * 新增、编辑保存页面
     *
     * @param #[base.primaryKey]
     * @return
     */
    @At("/view")
    @Ok("btl:#[base.templatePath]edit.html")
    @RequiresPermissions("#[base.entityName].index.edit")
    @AutoCreateMenuAuth(name = "查看详情", type = AutoCreateMenuAuth.RESOURCE, icon = "fa-cogs", parentPermission = "#[base.entityName].index")
    public NutMap view(@Param("#[base.primaryKey]") String #[base.primaryKey]) {
        return NutMap.NEW().setv("#[base.primaryKey]", #[base.primaryKey]).setv("fromDataEdit", false);
    }

    /**
     * 加载详情
     *
     * @param #[base.primaryKey]
     * @return
     */
    @At("/details")
    @Ok("json:{ignoreNull:false,dateFormat:'yyyy-MM-dd'}")
    @RequiresPermissions("#[base.entityName].index.edit")
    public AjaxResult details(@Param("#[base.primaryKey]") String #[base.primaryKey]) {
        return AjaxResult.sucess(#[sp.uncapitalize(base.serviceFileName)].fetch(#[base.primaryKey]));
    }


    /**
     * 批量删除
     *
     * @param #[base.primaryKey]s
     * @return
     */
    @At("/del")
    @Ok("json")
    @RequiresPermissions("#[base.entityName].index.del")
    @AutoCreateMenuAuth(name = "批量删除", type = AutoCreateMenuAuth.RESOURCE, icon = "fa-cogs", parentPermission = "#[base.entityName].index")
    public AjaxResult del(@Param("::#[base.primaryKey]s") String[] #[base.primaryKey]s) {
        <##if(base.uuid){ ##>
        #[sp.uncapitalize(base.serviceFileName)].deleteByUUIDs(#[base.primaryKey]s);
        <##}else{##>
        #[sp.uncapitalize(base.serviceFileName)].delete(#[base.primaryKey]s,false);
        <##}##>
        return AjaxResult.sucess("删除成功");
    }

    /**
     * 保存
     *
     * @param data
     * @return
     */
    @At("/save")
    @Ok("json")
    @POST
    @RequiresPermissions("#[base.entityName].index.edit")
    @Aop(TransAop.READ_UNCOMMITTED)
    public AjaxResult save(@Param("::fromData") #[base.entityName] data, Errors errors) {
        if (errors.hasError()) {
            return AjaxResult.error(errors.getErrorsList().iterator().next());
        }
        #[sp.uncapitalize(base.serviceFileName)].insertOrUpdate(data);
        return AjaxResult.sucessMsg("保存成功");
    }
}
