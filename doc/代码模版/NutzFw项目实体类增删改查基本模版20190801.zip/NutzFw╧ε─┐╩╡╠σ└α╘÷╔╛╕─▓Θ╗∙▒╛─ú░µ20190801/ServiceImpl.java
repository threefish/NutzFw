package #[base.serviceImplPackage];

import #[base.entityPackage].#[base.entityName];
import #[base.servicePackage].#[base.serviceFileName];
import com.nutzfw.core.common.service.impl.BaseServiceImpl;
import org.nutz.dao.Dao;
import org.nutz.ioc.loader.annotation.IocBean;

/**
 * @author #[base.userName] #[base.userMail]
 * @date #[date(), dateFormat="yyyy年MM月dd日"]
 * #[base.funName]
 */
@IocBean(args = {"refer:dao"}, name = "#[sp.uncapitalize(base.serviceFileName)]")
public class #[base.serviceImplFileName] extends BaseServiceImpl<#[base.entityName]>  implements #[base.serviceFileName] {
public #[base.serviceImplFileName](Dao dao){super(dao);}}
